<html>
<head>
    <style>
        h2
{
	text-align:center;
	margin-top:100px;
	color:#E0FFFF;
	font-size:80px;
	font-weight:bold;
}

.sign
{
	color:#008080;
	font-size:30px;
	margin-left:455px;
	font-weight:bold;
	border-bottom-style:solid;
	border-top-style:solid;
	border-left-style:solid;
	border-right-style:solid;
	border-bottom-color:#008080;
	border-right-color:#008080;
	border-top-color:#008080;
	border-left-color:#008080;
	width:fit-content;
	border-radius:50px;
	box-shadow: inset 0 0 0 50px #FFFFFF;	
	padding:3px;
}
.new
{
	color:blue;
	font-size:30px;
	margin-top:-30px;
	margin-left:700px;
	font-weight:bold;
}
.video_h
{
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  z-index: -1;
  
}
body
{
	background-size:cover;
	background-attachment:fixed;
	
}
img
{
	opacity:0.6;
}

.logo
{
	border-top-left-radius:20px;
	border-top-right-radius:20px;
	border-bottom-right-radius:20px;
    overflow: hidden;
}
.link
{
	text-decoration:none;
	color:inherit;
}
.about_us
{
	color:#008080;
	font-size:30px;
	margin-left:610px;
	font-weight:bold;
	border-bottom-style:solid;
	border-top-style:solid;
	border-left-style:solid;
	border-right-style:solid;
	border-bottom-color:#008080;
	border-right-color:#008080;
	border-top-color:#008080;
	border-left-color:#008080;
	width:fit-content;
	border-radius:50px;
	box-shadow: inset 0 0 0 50px #FFFFFF;	
	padding:3px;
}
body
{
	animation:transitionIn 3s;
}
/*@keyframes transitionIn
{
	from
	{
		opacity:0;
		transform:rotateX(-10deg);
	}
	to
	{
		opacity:1;
		transform:rotateX(0);
	}
}*/

.sign_one
{
	color:#008080;
	font-size:30px;
	margin-left:490px;
	font-weight:bold;
	border-bottom-style:solid;
	border-top-style:solid;
	border-left-style:solid;
	border-right-style:solid;
	border-bottom-color:#008080;
	border-right-color:#008080;
	border-top-color:#008080;
	border-left-color:#008080;
	width:fit-content;
	border-radius:50px;
	box-shadow: inset 0 0 0 50px #FFFFFF;	
	padding:3px;
}
  </style>
</head>

<body>
 <div class="logo">
 <img src="logo.jpg" width="100" height="100">
</div>

 <h2> AIS Learning <br> Empowered Your Future </h2>
 
 <div class="sign"
 <h3><a href="checkout.php" class="link">Registration for Premium Account </a></h3>
 </div>
<br>
 <div class="sign_one"
 <h3><a href="select_category.php" class="link">Registration for Free Account </a></h3>
 </div>

 <h3 class="about_us"><a href="aboutus.php" class="link">About Us</a></h3>
 
 
 
 <div class="video_h">
    <video autoplay loop muted plays-inline>
	    <source src="pexels-pavel-danilyuk-5734826 (1080p).mp4" type="video/mp4">
	</video>
</div>




</body>
</html>