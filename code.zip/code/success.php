<html>
  <head>
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
  </head>
    <style>
      body {
        text-align: center;
        padding: 40px 0;
        background: #EBF0F5;
      }
        h1 {
          color: #88B04B;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-weight: 900;
          font-size: 40px;
          margin-bottom: 10px;
        }
        p {
          color: #404F5E;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-size:20px;
          margin: 0;
        }
      i {
        color: #bc7a66;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
      body
{
    background-image:url("background.jpg");
    background-repeat:No-repeat;
    background-size:cover;
    background-attachment:fixed;
	animation:transitionIn 2s;
}
@keyframes transitionIn
{
	from
	{
		opacity:0;
		transform:rotateX(-10deg);
	}
	to
	{
		opacity:1;
		transform:rotateX(0);
	}
}
.course_button
{
    border-top-style:solid;
	border-bottom-style:solid;
	border-left-style:solid;
	border-right-style:solid;
	width:fit-content;
	margin-left:0.05cm;
	border-radius:50Px;
	box-shadow: inset 0 0 0 50px #116530;
	color:black; 
    font-weight:bold;
    font-size:20px;
}

    </style>
    <body>
    
      
      <!-- <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;"> -->
        <!-- <i class="checkmark">✓</i> -->
        <img src="check-mark-png-picture-3.png" >
      </div>
        <h1>Success</h1> 
        <p>We received your donation<br/> Thank You!</p>
        <a href="select_category_premium.php" class="link"> <input type="button" name="course" value="Go to Courses" class="course_button">
        <br>
        <br>
        <a href="first.php" class="link"> <input type="button" name="course" value="Home Page" class="course_button">
      </div>
    </body>
</html>