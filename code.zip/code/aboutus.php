<html>
    <head>
        <style>
            body
            {
                background-image:url("sexy-girl-pic-1920x1200-wallpaper-preview.jpg");
                background-repeat:no-repeat;
	            background-size:cover;
            }
            img
{
	opacity:0.6;
}

.logo
{
	border-top-left-radius:20px;
	border-top-right-radius:20px;
	border-bottom-right-radius:20px;
    overflow: hidden;
	margin-left:0.2cm;
	margin-top:0.2cm;
	
}
h1
{
	text-align:center;
	font-size:100px;
	font-weight:bold;
	color:#40E0D0;
	margin-top:2cm;
}
h3
{
	font-size:30px;
	text-align:center;
	font-weight:bold;
	color:#EDFDFE;	
}
body
{
	animation:transitionIn 2s;
}
@keyframes transitionIn
{
	from
	{
		opacity:0;
		transform:rotateX(-10deg);
	}
	to
	{
		opacity:1;
		transform:rotateX(0);
	} 
}
.video_h
{
  position:fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  z-index: -1;
}

</style>
</head>
<body>
<div class="logo">
 <img src="logo.jpg" width="100" height="100">
</div>

<!--div class="video_h">
    <video autoplay loop muted plays-inline>
	    <source src="video (1080p).mp4" type="video/mp4">
	</video>
</div-->
<h1> About Us </h1>

<h3> "Welcome to ASI Learning Company!

At ASI Learning, we're dedicated to revolutionizing<br> education through innovative, interactive, and personalized<br> learning experiences. Our mission is to empower<br> individuals worldwide with the skills and knowledge they<br> need to thrive in today's dynamic world.<br>

Founded in 2023, ASI Learning has been a pioneer in<br> merging cutting-edge technology with educational expertise.<br> We believe in the power of adaptive learning,<br> leveraging AI-driven platforms to tailor education to each<br> learner's unique needs, ensuring maximum engagement<br> and comprehension."<br>

</h3>
</body>
</html>
